
public class Cachorro extends Animal implements Domestico {
	private String raca;
	
	// Construtor
	public String getRaca() {
		return raca;
	}
	public void setRaca(String raca) {
		this.raca = raca;
	}
	public Cachorro(String nome, int idade, String raca) {
		super(nome, idade);
		this.raca = raca;
		// TODO Auto-generated constructor stub
	}
	// Polimorfismo - Sobrescrita de Método (modificando o método de outro lugar/reutilizando)
	@Override
	public void emitirSom() {
		System.out.println(getNome()+" está latindo!");
		
	}
	// Implementação de um método de um interface
	@Override
	public void brincar() {
		System.out.println(getNome() + " está brincando com a bola.");
	
	}
	//Método específico da subclasse
	public void abanarRabo() {
		System.out.println(getNome() + " está abanando o rabo.");
		
		
	}
	
	  
}
