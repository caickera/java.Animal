
public class Gato extends Animal implements Domestico{
	private boolean gostaCacar;
	// boolean (true or false)
	public boolean isGostaCacar() {
		return gostaCacar;
	}

	public void setGostaCacar(boolean gostaCacar) {
		this.gostaCacar = gostaCacar;
	}

	// Construtor
	public Gato(String nome, int idade, boolean gostaCacar) {
		super(nome, idade);
		this.gostaCacar = gostaCacar;
		// TODO Auto-generated constructor stub
	}

	public int calcularIdadeHumano() {
		int idadeHumano = this.getIdade() * 9;
		return idadeHumano;
	}
	@Override
	public void brincar() {
		System.out.println(getNome() + " está brincando com uma bolinha.");
		
	}

	@Override
	public void emitirSom() {
		System.out.println(getNome() + " está miando.");
		
	}
	// Método especifico
	public void ronronar() {
		System.out.println(getNome() + " está ronronando.");
	}
}
