
public class Main {

	public static void main(String[] args) {
		//Instância de objetos
		Cachorro cachorro = new Cachorro("Rex",5,"Pastor Alemão");
		Gato gato = new Gato("Faiska",3,true);
		
		if(gato.getIdade() >=3) {
			System.out.println(gato.getIdade()+ " têm " + gato.getIdade() + " anos na idade de gato.");
			System.out.println("28 anos ma idade de humano.");
		}
		
		System.out.println("Idade humano: " + gato.calcularIdadeHumano());
		
		cachorro.emitirSom();
		gato.emitirSom();
		
		cachorro.brincar();
		gato.brincar();
		
		cachorro.setNome("Max");
		System.out.println("Novo nome do cachorro é " + cachorro.getNome());
		
		gato.setIdade(6);
		System.out.println("Nome idade do gato é " + gato.getIdade());
	}

}
