
public interface Domestico {
	public void brincar();
}
